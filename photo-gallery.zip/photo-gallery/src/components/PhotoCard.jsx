import { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faThumbsUp } from '@fortawesome/free-solid-svg-icons'

// Picsum serves resized images at /id/{id}/{width}/{height}, which is much
// lighter than loading the full-size download_url for a small thumbnail.
function thumbnailUrl(photo) {
  const width = 200
  const height = Math.round((photo.height / photo.width) * width)
  return `https://picsum.photos/id/${photo.id}/${width}/${height}`
}

export default function PhotoCard({ photo }) {
  const [likes, setLikes] = useState(0)

  return (
    <li className="photo-card">
      <a href={photo.download_url} target="_blank" rel="noreferrer">
        <img
          className="photo-card__image"
          src={thumbnailUrl(photo)}
          alt={`Photo by ${photo.author}`}
          width={200}
          loading="lazy"
        />
      </a>
      <span className="photo-card__author">Author: {photo.author}</span>
      <button
        type="button"
        className="like-button"
        onClick={() => setLikes((count) => count + 1)}
        aria-label={`Like photo by ${photo.author}`}
      >
        <FontAwesomeIcon icon={faThumbsUp} />
      </button>
      <span className="like-count" aria-live="polite">
        {likes}
      </span>
    </li>
  )
}
