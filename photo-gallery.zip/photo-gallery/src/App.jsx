import { useCallback, useEffect, useRef, useState } from 'react'
import PhotoCard from './components/PhotoCard.jsx'

const FEED_URL = 'https://picsum.photos/v2/list'

export default function App() {
  const [photos, setPhotos] = useState([])
  const [nextPage, setNextPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  // A ref (not state) guards against firing two requests for the same page
  // when the observer triggers again before React re-renders.
  const isFetching = useRef(false)
  const sentinelRef = useRef(null)

  const loadNextPage = useCallback(async () => {
    if (isFetching.current || !hasMore) return
    isFetching.current = true
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`${FEED_URL}?page=${nextPage}`)
      if (!response.ok) throw new Error(`Request failed (${response.status})`)
      const data = await response.json()

      if (data.length === 0) {
        // An empty page means we've reached the end of the feed.
        setHasMore(false)
      } else {
        setPhotos((prev) => {
          // Skip any duplicates, just in case a page is ever requested twice.
          const seen = new Set(prev.map((p) => p.id))
          return [...prev, ...data.filter((p) => !seen.has(p.id))]
        })
        setNextPage((page) => page + 1)
      }
    } catch (err) {
      setError(err.message)
    } finally {
      isFetching.current = false
      setLoading(false)
    }
  }, [nextPage, hasMore])

  // Watch an empty element at the bottom of the list. When it scrolls into
  // view, load the next page. Re-subscribing after every load also handles
  // the case where the first page doesn't fill the screen.
  useEffect(() => {
    const sentinel = sentinelRef.current
    if (!sentinel || !hasMore || error) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadNextPage()
      },
      { rootMargin: '200px' },
    )
    observer.observe(sentinel)
    return () => observer.disconnect()
  }, [loadNextPage, hasMore, error, photos.length])

  return (
    <main className="gallery">
      <h1 className="gallery__title">Photo gallery</h1>

      <ul className="photo-list">
        {photos.map((photo) => (
          <PhotoCard key={photo.id} photo={photo} />
        ))}
      </ul>

      {loading && <p className="status">Loading more photos…</p>}

      {error && (
        <p className="status status--error">
          Couldn't load photos: {error}{' '}
          <button type="button" className="retry-button" onClick={loadNextPage}>
            Try again
          </button>
        </p>
      )}

      {!hasMore && <p className="status">You've reached the end. No more photos.</p>}

      <div ref={sentinelRef} aria-hidden="true" />
    </main>
  )
}
